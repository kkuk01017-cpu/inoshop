-- iNO Shop: inventory upgrade (existing members, balances, topups and products are preserved)
create extension if not exists pgcrypto;

alter table public.products
  add column if not exists status text not null default 'maintenance'
    check (status in ('available','sold_out','maintenance')),
  add column if not exists stock_quantity integer not null default 0 check (stock_quantity >= 0);

alter table public.orders add column if not exists delivered_code text;

create table if not exists public.product_stock (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  secret_code text not null,
  created_at timestamptz not null default now()
);
create index if not exists product_stock_product_idx on public.product_stock(product_id,created_at);

alter table public.product_stock enable row level security;
drop policy if exists "admin manage product stock" on public.product_stock;
create policy "admin manage product stock" on public.product_stock
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create or replace function public.sync_product_stock_count()
returns trigger language plpgsql security definer set search_path=public
as $$
declare pid uuid;
begin
  pid := coalesce(new.product_id,old.product_id);
  update public.products set stock_quantity=(select count(*)::int from public.product_stock where product_id=pid) where id=pid;
  if tg_op='UPDATE' and old.product_id is distinct from new.product_id then
    update public.products set stock_quantity=(select count(*)::int from public.product_stock where product_id=old.product_id) where id=old.product_id;
  end if;
  return coalesce(new,old);
end;
$$;
drop trigger if exists product_stock_count_trigger on public.product_stock;
create trigger product_stock_count_trigger after insert or delete or update of product_id
on public.product_stock for each row execute function public.sync_product_stock_count();

update public.products p
set stock_quantity=(select count(*)::int from public.product_stock s where s.product_id=p.id);

-- Secure product stock from public reads; only admins can see unsold codes.
create or replace function public.buy_product(p_product_id uuid)
returns uuid language plpgsql security definer set search_path=public
as $$
declare p public.products%rowtype; s public.product_stock%rowtype; new_order uuid;
begin
  if auth.uid() is null then raise exception 'กรุณาเข้าสู่ระบบก่อนซื้อสินค้า'; end if;
  select * into p from public.products where id=p_product_id for update;
  if not found or not p.active or p.status<>'available' then raise exception 'สินค้านี้ปิดขายหรือไม่พร้อมจำหน่าย'; end if;
  select * into s from public.product_stock where product_id=p_product_id order by created_at,id limit 1 for update;
  if not found then
    update public.products set status='sold_out',active=false,stock_quantity=0 where id=p_product_id;
    raise exception 'สินค้าหมดแล้ว';
  end if;
  update public.profiles set balance=balance-p.price where id=auth.uid() and balance>=p.price;
  if not found then raise exception 'ยอดเงินไม่เพียงพอ'; end if;
  insert into public.orders(user_id,product_id,product_name,price,delivery_url,delivered_code,status)
  values(auth.uid(),p.id,p.name,p.price,null,s.secret_code,'delivered') returning id into new_order;
  insert into public.wallet_transactions(user_id,amount,note,related_id)
  values(auth.uid(),-p.price,'ซื้อสินค้า: '||p.name,new_order);
  delete from public.product_stock where id=s.id;
  update public.products
  set stock_quantity=(select count(*)::int from public.product_stock where product_id=p_product_id),
      status=case when (select count(*) from public.product_stock where product_id=p_product_id)=0 then 'sold_out' else 'available' end,
      active=case when (select count(*) from public.product_stock where product_id=p_product_id)=0 then false else true end
  where id=p_product_id;
  return new_order;
end;
$$;

create or replace function public.admin_set_product_status(p_product_id uuid,p_status text)
returns void language plpgsql security definer set search_path=public
as $$
begin
  if not public.is_admin() then raise exception 'ต้องเป็นแอดมินเท่านั้น'; end if;
  if p_status not in ('available','sold_out','maintenance') then raise exception 'สถานะไม่ถูกต้อง'; end if;
  if p_status='available' and not exists(select 1 from public.product_stock where product_id=p_product_id) then
    raise exception 'ต้องเพิ่มสต็อกก่อนเปิดขาย';
  end if;
  update public.products set status=p_status,active=(p_status='available') where id=p_product_id;
  if not found then raise exception 'ไม่พบสินค้า'; end if;
end;
$$;

-- Customer can read active products; admins can read all products.
drop policy if exists "active products readable" on public.products;
create policy "active products readable" on public.products
for select to anon,authenticated using ((active=true and status='available') or public.is_admin());

revoke all on function public.buy_product(uuid) from public;
grant execute on function public.buy_product(uuid) to authenticated;
revoke all on function public.admin_set_product_status(uuid,text) from public;
grant execute on function public.admin_set_product_status(uuid,text) to authenticated;
